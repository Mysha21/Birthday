# 🎂 Cake Blow

An interactive **Birthday Cake Web App** 🎉  
Add candles, share a special link with friends, and let them blow the candles out using their microphone 🎤.

---

## 🚀 How to Use
1. Open the site.
2. Click **Add Candle** to add as many candles as you like.
3. Click **Generate Share Link** → copy the link and send it to your friend.
4. Your friend opens the link → sees your cake → and can blow the candles out!

---

## 🛠 How to Deploy on GitHub Pages

1. Download or clone this repo.
2. Upload files (`index.html`, `style.css`, `script.js`) to a GitHub repository.
3. In your repo → **Settings → Pages**.
4. Under **Branch**, select `main` (or `master`) and folder `/ (root)`.
5. Click **Save**.  
   After 1 minute, your site will be live at:  
   ```
   https://your-username.github.io/cake-blow/
   ```

---

## ✨ Example Share Link
If you add 5 candles, the share link will look like:

```
https://your-username.github.io/cake-blow/?candles=5
```

Send that link to your friend — they’ll see the cake with 5 candles and can blow them out.

---

## 📜 License
MIT License – free to use, modify, and share.
